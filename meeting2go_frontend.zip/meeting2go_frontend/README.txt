MEETING2GO FRONT-END DEMO
1. Extract the ZIP.
2. Open index.html in Chrome or Edge with an internet connection (QR libraries load from CDN).
3. Click Create account, register an email and password, then sign in.
4. Complete Organization, Event, and import members_sample.csv (or your own CSV up to 500 rows).
5. Select a member under QR Check-in to generate/download QR. Click manual check-in or scan with camera.
6. Open Attendance Report and Export CSV.

For camera scanning, serve this folder on http://localhost (XAMPP htdocs) or HTTPS; opening file:// may block camera permissions.
Example: copy folder to C:\xampp\htdocs\meeting2go_frontend and visit http://localhost/meeting2go_frontend/

IMPORTANT: This is a LOCAL DEMO, not a production authentication system. Passwords and records are stored in browser localStorage; do not use real passwords or sensitive member information. A production deployment needs PHP/MySQL or another secure server, password hashing, sessions, access control, and server-side QR validation. QR codes in this demo are not cryptographically protected against copying/forgery.
